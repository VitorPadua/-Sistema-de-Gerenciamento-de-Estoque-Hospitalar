package org.example.estoque.controller;

import org.example.estoque.model.Produto;
import org.example.estoque.service.ProdutoService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoService service;

    public ProdutoController(ProdutoService service) {
        this.service = service;
    }

    @PostMapping
    public Produto registrar(@RequestBody Produto produto) {
        return service.registrarProduto(produto);
    }

    @GetMapping("/{id}")
    public Produto consultar(@PathVariable int id) {
        return service.consultarProduto(id);
    }

    @PostMapping("/{id}/adicionar")
    public Produto adicionarQuantidade(@PathVariable int id, @RequestParam int qtd) {
        return service.adicionarQuantidade(id, qtd);
    }

    @PutMapping("/{id}")
    public Produto editar(@PathVariable int id, @RequestBody Produto dados) {
        return service.editarProduto(id, dados.getNome(), dados.getQuantidade());
    }

    @DeleteMapping("/{id}")
    public String excluir(@PathVariable int id) {
        service.excluirProduto(id);
        return "Produto removido.";
    }
}
