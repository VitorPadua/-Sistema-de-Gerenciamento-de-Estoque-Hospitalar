package org.example.estoque.service;

import org.example.estoque.model.Produto;
import org.example.estoque.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

@Service
public class ProdutoService {

    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    public Produto registrarProduto(Produto produto) {
        if(repository.existsById(produto.getId())) {
            throw new RuntimeException("ID já existe!");
        }
        return repository.save(produto);
    }

    public Produto consultarProduto(int id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado."));
    }

    public Produto adicionarQuantidade(int id, int qtd) {
        Produto p = consultarProduto(id);
        p.setQuantidade(p.getQuantidade() + qtd);
        return repository.save(p);
    }

    public Produto editarProduto(int id, String nome, Integer quantidade) {
        Produto p = consultarProduto(id);

        if(nome != null && !nome.trim().isEmpty())
            p.setNome(nome);

        if(quantidade != null && quantidade >= 0)
            p.setQuantidade(quantidade);

        return repository.save(p);
    }

    public void excluirProduto(int id) {
        Produto p = consultarProduto(id);
        repository.delete(p);
    }
}
