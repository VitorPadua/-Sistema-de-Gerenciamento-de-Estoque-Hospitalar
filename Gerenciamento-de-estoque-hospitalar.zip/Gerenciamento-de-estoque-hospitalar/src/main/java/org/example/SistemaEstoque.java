package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// Classe que simula o CRUD do estoque hospitalar
class SistemaEstoque {
    private List<Produto> produtos = new ArrayList<>();

    // Função auxiliar para encontrar um produto (melhoria de consultarProduto)
    private Optional<Produto> buscarProdutoPorId(int id) {
        for (Produto p : produtos) {
            if (p.getId() == id) {
                return Optional.of(p);
            }
        }
        return Optional.empty();
    }

    // UC001: Registrar Produto no estoque (Adicionar um novo produto)
    public void registrarProduto(int id, String nome, int quantidade) {
        if (buscarProdutoPorId(id).isPresent()) {
            System.out.println("❌ Erro: Já existe um produto com o ID " + id + ".\n");
            return;
        }

        Produto produto = new Produto(id, nome, quantidade);
        produtos.add(produto);
        System.out.println("✔ Produto registrado com sucesso!\n");
    }

    // UC003: Consultar Produto pelo ID
    public void consultarProduto(int id) {
        Optional<Produto> produtoOpt = buscarProdutoPorId(id);

        if (produtoOpt.isPresent()) {
            System.out.println("🔎 Produto encontrado:");
            System.out.println(produtoOpt.get());
        } else {
            System.out.println("❌ Produto não cadastrado/encontrado.\n");
        }
    }

    // UC002: Adicionar Produto no estoque (Aumentar a quantidade)
    public void adicionarQuantidade(int id, int quantidadeAdicional) {
        Optional<Produto> produtoOpt = buscarProdutoPorId(id);

        if (produtoOpt.isPresent()) {
            Produto produto = produtoOpt.get();
            int novaQuantidade = produto.getQuantidade() + quantidadeAdicional;
            produto.setQuantidade(novaQuantidade);
            System.out.println("✔ Estoque atualizado! Nova quantidade de " + produto.getNome() + ": " + novaQuantidade + "\n");
        } else {
            System.out.println("❌ Produto não encontrado. Use a opção '1' para registrar um novo produto.\n");
        }
    }

    // UC005: Editar produto no estoque (Alterar nome ou quantidade)
    public void editarProduto(int id, String novoNome, int novaQuantidade) {
        Optional<Produto> produtoOpt = buscarProdutoPorId(id);

        if (produtoOpt.isPresent()) {
            Produto produto = produtoOpt.get();

            // Lógica para edição (permite mudar nome E/OU quantidade)
            if (novoNome != null && !novoNome.trim().isEmpty()) {
                produto.setNome(novoNome);
            }
            if (novaQuantidade >= 0) { // Garante que a quantidade não será negativa
                produto.setQuantidade(novaQuantidade);
            }

            System.out.println("✔ Produto editado com sucesso!");
            System.out.println("Atualizado: " + produto + "\n");
        } else {
            System.out.println("❌ Produto não encontrado.\n");
        }
    }

    // UC004: Excluir Produto no estoque
    public void excluirProduto(int id) {
        Optional<Produto> produtoOpt = buscarProdutoPorId(id);

        if (produtoOpt.isPresent()) {
            Produto produto = produtoOpt.get();
            produtos.remove(produto);
            System.out.println("✔ Produto '" + produto.getNome() + "' (ID: " + id + ") removido com sucesso.\n");
        } else {
            System.out.println("❌ Produto não encontrado.\n");
        }
    }
}