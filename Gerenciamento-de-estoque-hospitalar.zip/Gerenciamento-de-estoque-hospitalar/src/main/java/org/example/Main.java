package org.example;

import java.util.Scanner;

// Classe principal
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SistemaEstoque sistema = new SistemaEstoque();
        int opcao;

        do {
            System.out.println("\n==== ESTOQUE HOSPITALAR ====");
            System.out.println("1 - Registrar Novo Produto (UC001)"); // Antigo Adicionar Produto
            System.out.println("2 - Consultar Produto (UC003)");
            System.out.println("3 - Adicionar Quantidade ao Estoque (UC002)");
            System.out.println("4 - Editar Produto (UC005)");
            System.out.println("5 - Excluir Produto (UC004)");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");

            // Tratamento básico para garantir que a entrada seja um número
            if (sc.hasNextInt()) {
                opcao = sc.nextInt();
                sc.nextLine(); // Limpar buffer após nextInt
            } else {
                System.out.println("Opção inválida! Digite um número.");
                sc.nextLine(); // Limpar a linha de entrada inválida
                opcao = -1; // Força default case
                continue; // Volta ao início do loop
            }


            switch (opcao) {
                // UC001: Registrar Novo Produto
                case 1:
                    System.out.print("ID do produto: ");
                    int idRegistro = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nome do produto: ");
                    String nomeRegistro = sc.nextLine();

                    System.out.print("Quantidade inicial: ");
                    int quantidadeRegistro = sc.nextInt();
                    sc.nextLine();

                    sistema.registrarProduto(idRegistro, nomeRegistro, quantidadeRegistro);
                    break;

                // UC003: Consultar Produto
                case 2:
                    System.out.print("Informe o ID para consulta: ");
                    int idConsulta = sc.nextInt();
                    sc.nextLine();
                    sistema.consultarProduto(idConsulta);
                    break;

                // UC002: Adicionar Quantidade ao Estoque
                case 3:
                    System.out.print("Informe o ID do produto para adicionar quantidade: ");
                    int idAdicionar = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Informe a quantidade a ser adicionada: ");
                    int qtdAdicionar = sc.nextInt();
                    sc.nextLine();

                    sistema.adicionarQuantidade(idAdicionar, qtdAdicionar);
                    break;

                // UC005: Editar Produto
                case 4:
                    System.out.print("Informe o ID do produto a ser editado: ");
                    int idEdicao = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Novo Nome (deixe em branco para manter): ");
                    String novoNome = sc.nextLine();

                    System.out.print("Nova Quantidade (digite -1 para manter): ");
                    int novaQtd = sc.nextInt();
                    sc.nextLine();

                    sistema.editarProduto(idEdicao, novoNome, novaQtd);
                    break;

                // UC004: Excluir Produto
                case 5:
                    System.out.print("Informe o ID do produto para exclusão: ");
                    int idExclusao = sc.nextInt();
                    sc.nextLine();
                    sistema.excluirProduto(idExclusao);
                    break;

                case 0:
                    System.out.println("Encerrando sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

        sc.close();
    }
}